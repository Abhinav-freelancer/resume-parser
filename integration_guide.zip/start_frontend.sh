#!/bin/bash
echo "🎨 Starting AI Hiring Frontend..."
echo "🌐 Application will be available at: http://localhost:3000"
echo ""

python -m http.server 3000
